﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Павел_кечуткин_проект_по_с__
{
    public partial class klanUchiha : Form
    {
        public klanUchiha()
        {
            InitializeComponent();
        }

        private void klanUchiha_Load(object sender, EventArgs e)
        {
            

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Contains("klanUchiha"))
                pictureBox3.Visible = true;
            else
                pictureBox3.Visible = true
        }
    }
}
